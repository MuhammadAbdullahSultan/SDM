var path = require('path');
var firebase = require('firebase');

firebase.initializeApp({
  databaseURL: 'https://oss-test.firebaseio.com'
});
